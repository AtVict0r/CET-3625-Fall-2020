function key = testGetKey()
  prompt = ["Enter first digit for key: ", "Enter second digit for key: ", "Enter third digit for key: ", " Enter fourth digit for key: "];
  
  disp("Enter the four digit passcode to encrpt/decrypt your message.");
  disp("Passcode cannot contain a zero.");
  key = zeros(4);
  
  while 1
      key = str2double((inputdlg(prompt, "Encryption Key"))');
      
      if(~(all(key))) 
          uiwait(msgbox('You cannot use zero as a key','Warning','modal'));
      elseif(~(length(key) == length(unique(key))))
          uiwait(msgbox('Key has to be unique, repeating numbers is not allowed','Warning','modal'));
      else
          break;
      end
  end
  
  if(isempty(key))
      key = [4, 3; 5, -3];
  else
      key = [key([1:2]); key([3:4])];
  end
end