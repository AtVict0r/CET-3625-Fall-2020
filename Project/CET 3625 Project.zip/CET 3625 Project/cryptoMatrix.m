% https://www.instructables.com/Encrypt-a-message-using-matrixes/
%________________________________________________________________

function [myMessage, encryptKey] = cryptoMatrix()
    program = 1;
    encryptKey = [4, 3; 5, -3]; % Create encryption key
    
    function [indx, tf] = menu()
        list = {'Encrypt Message','Decrypt Message','Change Key', 'About', 'Quit'};
        [indx, tf] = listdlg('SelectionMode','single','ListString',list);
    end
    
    function message = encryptMessage() % Function for encrypting message
        while 1
            message = cell2mat(inputdlg('Enter short message:', 'Encrypt Message')); % Get user input as char array
    
            if isempty(message) % Check if user input is valid
                uiwait(msgbox('Empty variable','Warning','modal')); % Error message for invalid input
                continue; % Continue while loop
            else
                asciiVal = double(message); % Convert string to double (default MATLAB type)
                c1 = asciiVal([1:2:length(asciiVal)]); % Create a vector of all odd position values
                c2 = asciiVal([2:2:length(asciiVal)]); % Create a vector of all even position values
    
                if (rem(length(asciiVal), 2) == 1) % Check if vector length is even
                    c2(length(c1)) = 32; % Make vector length even by adding blank space
                end % End if (even or odd vector check)
    
                asciiVal = [c1; c2]'; % Create groups of two by combining column 1 and 2 and transpose final matrix
            end % End if else (vector length check)
        
            encryptMessage = (asciiVal * encryptKey)'; % Return transposed matrix with encrypted message
    
            message = (encryptMessage(:))'; % Convert matrix to column vector and transpose to row vector
            newMessage = cellstr(strjoin(string(message))); % Convert row vector to string cell array
    
            inputdlg('Encrypted Message:','Message Box',[1, length(message)*3], newMessage); % Show result to user
            break; % Exit while loop
         end % End while loop 
        end % End function
 
        function message = decryptMessage() % Function for decrypting message
            while 1
                message = strsplit(cell2mat(inputdlg('Enter encryted message:', 'Decrypt Message')), ' '); % Get user input as double array
                % Get input as cell array -> Convert cell array to string matrix -> Split string matrix to char matrix 
    
                if isempty(message) % Check if user input is valid
                    uiwait(msgbox('Empty variable','Warning','modal')); % Error message for invalid input
                    continue; % Continue while loop
                else
                    asciiVal = str2double(message); % Convert char matrix to double (default MATLAB type)
                    c1 = asciiVal([1:2:length(asciiVal)]); % Create a vector of all odd position values
                    c2 = asciiVal([2:2:length(asciiVal)]); % Create a vector of all even position values
    
                    asciiVal = [c1; c2]'; % Create groups of two by combining column 1 and 2 and transpose final matrix
                end % End if else (vector length check)
        
                decryptedMessage = (asciiVal / encryptKey)'; % Return transposed matrix with encrypted message
                decryptedMessage = (decryptedMessage(:))'; % Convert matrix to column vector and transpose to row vector
                decryptedMessage(int16(decryptedMessage) == 32) = ','; % Replace space with comma
                message = strrep(char(decryptedMessage), ',', ' '); % Replace comma with space
                newMessage = cellstr(message); % Convert string to cell array
    
                inputdlg('Decrypted Message:','Message Box',[1, length(message)*3], newMessage); % Show result to user
                break; % Exit while loop
            end % End while loop 
        end
 
        function key = getKey()
            prompt = ["Enter first digit for key: ", "Enter second digit for key: ", "Enter third digit for key: ", " Enter fourth digit for key: "];
  
            disp("Enter the four digit passcode to encrpt/decrypt your message.");
            disp("Passcode cannot contain a zero.");
            key = zeros(4);
  
            while 1
                key = str2double((inputdlg(prompt, "Encryption Key"))');
      
                if(~(all(key))) 
                    uiwait(msgbox('You cannot use zero as a key','Warning','modal'));
                elseif(~(length(key) == length(unique(key))))
                    uiwait(msgbox('Key has to be unique, repeating numbers is not allowed','Warning','modal'));
                else
                    break;
                end
            end
  
            if(isempty(key))
                key = [4, 3; 5, -3];
            else
                key = [key([1:2]); key([3:4])];
            end
        end
    
        function about()
            uiwait(msgbox('Encrypt and decrypt a message using matrix','About','modal')); 
        end
        
        while program
            switch menu()
                case 1
                    myMessage = encryptMessage();
                case 2
                    myMessage = decryptMessage();
                case 3
                    encryptKey = getKey();
                case 4
                    about()
                case 5
                    answer = questdlg('Would you like to quit?', 'Quit Program', 'Yes','No', 'No');
                    % Handle response
                    if(strcmp(answer, 'Yes'))
                        program = 0;
                    else
                        program = 1;
                    end
            end
        end
end