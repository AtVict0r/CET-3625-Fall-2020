function message = testDecryptMessage() % Function for decrypting message
   while 1
    message = strsplit(cell2mat(inputdlg('Enter encryted message:', 'Decrypt Message')), ' '); % Get user input as double array
    % Get input as cell array -> Convert cell array to string matrix -> Split string matrix to char matrix 
    
    if isempty(message) % Check if user input is valid
      uiwait(msgbox('Empty variable','Warning','modal')); % Error message for invalid input
      continue; % Continue while loop
    else
      asciiVal = str2double(message); % Convert char matrix to double (default MATLAB type)
      c1 = asciiVal([1:2:length(asciiVal)]); % Create a vector of all odd position values
      c2 = asciiVal([2:2:length(asciiVal)]); % Create a vector of all even position values
    
      asciiVal = [c1; c2]'; % Create groups of two by combining column 1 and 2 and transpose final matrix
      encyptKey = [4, 3; 5, -3]; % Create encryption key
    end % End if else (vector length check)
        
    decryptedMessage = (asciiVal / encyptKey)'; % Return transposed matrix with encrypted message
    decryptedMessage = (decryptedMessage(:))'; % Convert matrix to column vector and transpose to row vector
    decryptedMessage(int16(decryptedMessage) == 32) = ','; % Replace space with comma
    message = strrep(char(decryptedMessage), ',', ' '); % Replace comma with space
    newMessage = cellstr(message); % Convert string to cell array
    
    inputdlg('Decrypted Message:','Message Box',[1, length(message)*3], newMessage); % Show result to user
    break; % Exit while loop
  end % End while loop 
end