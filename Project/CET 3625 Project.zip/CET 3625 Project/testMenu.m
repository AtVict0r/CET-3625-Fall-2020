function [indx, tf] = testMenu()
    list = {'Encrypt Message','Decrypt Message','Change Key', 'About', 'Quit'};
    [indx,tf] = listdlg('SelectionMode','single','ListString',list);
end